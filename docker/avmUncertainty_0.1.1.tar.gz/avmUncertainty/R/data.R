#'
#'  Custom mapping of assessor areas to 'submarkets'.
#'
#' @format A data.frame (tbl)
#' @source Manually put together with code in /scripts/create_project_data.R
"submarket_df"
